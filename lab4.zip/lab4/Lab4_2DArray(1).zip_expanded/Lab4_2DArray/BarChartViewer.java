import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;

public class BarChartViewer extends JPanel implements ActionListener, Serializable {
    private BarChart chart;  
    private Timer timer;
    private int[][] data = {
        {20, 30, 40, 50},
        {50, 60, 70, 80},
        {90, 100, 110, 120},
        {130, 140, 150, 160}
    };

    public BarChartViewer() {
        chart = new BarChart(data);  
        timer = new Timer(1000, this); 
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      
        repaint();  
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        chart.draw(g);  // Call the draw method from BarChart to display the chart
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("BarChart Viewer");
        BarChartViewer viewer = new BarChartViewer();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.add(viewer);
        frame.setVisible(true);
    }
}
